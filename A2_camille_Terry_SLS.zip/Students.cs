﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2_firstname_lastname_SLS
{
    public class Students
    {

            private string _firstName;
            private string _lastName;
            private long _wNum;
            private long _ssn;
            private Book[] _booksCheckedOut;
            private int _numberOfBooksCheckedOut;

            public Students()
            {
                _firstName = "John";
                _lastName = "Doe";
                _wNum = 0;
                _ssn = 0;
                _booksCheckedOut = new Book[3];
                _numberOfBooksCheckedOut = 0;
            }

            public Students(string firstName, string lastName, long wNum, long ssn)
            {
                _firstName = firstName;
                _lastName = lastName;
                _wNum = wNum;
                _ssn = ssn;
                _booksCheckedOut = new Book[3];
                _numberOfBooksCheckedOut = 0;
            }

            public bool maxRentedLimit()
            {
                if (_numberOfBooksCheckedOut >= 3)
                {
                    return true;
                }
                return false;
            }

            public void CheckOutBook(Book book, Catalog catalog)
            {
                if (!maxRentedLimit())
                {
                    for (int i = 0; i < _booksCheckedOut.Length; i++)
                    {
                        if (_booksCheckedOut[i] == null)
                        {
                            catalog.CheckOutBook(this, book);
                            book.MarkIFCheckedOut();
                            _booksCheckedOut[i] = book;
                            _numberOfBooksCheckedOut++;
                            i = _booksCheckedOut.Length;
                        }
                    }
                }
                else
                {
                    throw new Exception("Student has too many Books Being Rented");
                }
            }

            public void ReturnBook(Book book, Catalog catalog)
            {
                if (book != null && catalog != null && _booksCheckedOut.Any(x => x.GetIsbn() == book.GetIsbn()))
                {
                    for (int i = 0; i < _booksCheckedOut.Length; i++)
                    {
                        if (_booksCheckedOut[i] != null && _booksCheckedOut[i].GetIsbn() == book.GetIsbn())
                        {
                            catalog.ReturnBook(this, book);
                            _booksCheckedOut[i] = null;
                            _numberOfBooksCheckedOut--;
                            i = _booksCheckedOut.Length;

                        }
                    }
                }
            }

            public void PrintStudentInfo()
            {
                Console.WriteLine("-----------------------------");
                Console.WriteLine("Student Info");
                Console.WriteLine("Name: " + _firstName + " " + _lastName);
                Console.WriteLine("W#: " + _wNum);
                Console.WriteLine("SSN: " + _ssn);
                Console.WriteLine("-----------------------------");
            }

            public void PrintListOfBooksCheckedOut()
            {
                Console.WriteLine("-----------------------------");
                Console.WriteLine("Printing Books Checked Out");
                foreach (Book book in _booksCheckedOut)
                {
                    if (book != null)
                    {
                        book.PrintBookInfo();
                    }

                }
            }

            public Book[] GetBooksCheckedOut()
            {
                return _booksCheckedOut;
            }


        }
    }
