﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2_firstname_lastname_SLS
{
    public class SLS
    {

        public Catalog _catalog;
        public Librarian _librarian;
        public List<Students> _students;
        public long _numOfStudents;
        public SLS(bool populateLibrary, int numOfBooksOrStud)
        {
            Random rand = new Random();
            int employeeId = rand.Next(1, 1000);
            _catalog = new Catalog(employeeId);
            _librarian = new Librarian("Camille", "Terry", "3848 Harrison Blvd, Ogden, UT 84408", 7654321, employeeId);
            _students = new List<Students>();
            if (populateLibrary)
            {
                List<Book> books = GetListOfRandomBooks(numOfBooksOrStud);
                foreach (Book b in books)
                {
                    _catalog.AddBook(_librarian, b);
                }
                _students = GetListOfRandomStudents(numOfBooksOrStud);

            }

            _numOfStudents = _students.Count();
        }

        public SLS(Librarian librarian)
        {
            _catalog = new Catalog(librarian.GetId());
            _librarian = librarian;
            _students = new List<Students>();
            _numOfStudents = 0;
        }

        public SLS(Librarian librarian, List<Students> students, List<Book> books)
        {
            _catalog = new Catalog(librarian.GetId());
            foreach (Book b in books)
            {
                _catalog.AddBook(librarian, b);
            }
            _librarian = librarian;
            _students = students;
            _numOfStudents = _students.Count();
        }



        public void AddAStudent(Students student)
        {
            _students.Add(student);
            _numOfStudents = _students.Count();
        }

        public void RemoveAStudent(Students student)
        {
            if (_students.Contains(student))
            {
                _students.Remove(student);
            }
            _numOfStudents = _students.Count();
        }

        public long NumberOfStudents()
        {
            return _numOfStudents;
        }

        public void GenerateRandomStudents(int numStudents)
        {
            Students s;
            Random rand = new Random();

            for (int i = 0; i < numStudents; i++)
            {
                s = new Students("Student" + i, "lastName", i, 2000 + i);
                _students.Add(s);
            }
        }

        public List<Students> GetListOfRandomStudents(int n)
        {
            Students student;
            List<Students> students = new List<Students>();
            Random rand = new Random();

            for (int i = 0; i < n; i++)
            {
                student = new Students("Student" + i, "lastName", i, 2000 + i);
                students.Add(student);
            }

            return students;
        }



        public List<Book> GetListOfRandomBooks(int numBooks)
        {
            Book book;
            List<Book> books = new List<Book>();
            Random rand = new Random();

            for (int i = 0; i < numBooks; i++)
            {
                book = new Book(i, "Book" + i, "author", (1000 + i).ToString(), BookType.art, BookLocation.firstFloor);
                books.Add(book);
            }

            return books;
        }

        public List<Students> GetTotalStudents()
        {
            return _students;
        }

    }
}
